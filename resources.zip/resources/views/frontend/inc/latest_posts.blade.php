<section class="elementor-section elementor-top-section elementor-element elementor-element-c5dc6a4 elementor-reverse-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c5dc6a4" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
      <div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-e08a116" data-id="e08a116" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
                  <div class="elementor-element elementor-element-fbae4bb elementor-cta--skin-cover elementor-cta--valign-bottom elementor-bg-transform elementor-bg-transform-zoom-in elementor-widget elementor-widget-call-to-action animated fadeInUp" data-id="fbae4bb" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}" data-widget_type="call-to-action.default">
<div class="elementor-widget-container">
<link rel="stylesheet" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor-pro/assets/css/widget-call-to-action.min.css">		<div class="elementor-cta">
<div class="elementor-cta__bg-wrapper">
<div class="elementor-cta__bg elementor-bg" style="background-image: url(https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/bitcoin-coin-in-blue-neon-close-up-against-blurred-graphs-world-cryptocurrency.jpg);"></div>
<div class="elementor-cta__bg-overlay"></div>
</div>
            <div class="elementor-cta__content">

<h3 class="elementor-cta__title elementor-cta__content-item elementor-content-item">Start To Invest And Earn More</h3>
                        <div class="elementor-cta__description elementor-cta__content-item elementor-content-item">
                              We believe every investor should have access to high quality real estate and blockchain assets.				</div>

                        <div class="elementor-cta__button-wrapper elementor-cta__content-item elementor-content-item ">
<a class="elementor-cta__button elementor-button elementor-size-sm" href="{{ route('Deposit.index') }}">
      Invest Now					</a>
</div>
            </div>
      </div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-6d9ec6e animated fadeInRight" data-id="6d9ec6e" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInRight&quot;}">
<div class="elementor-widget-wrap elementor-element-populated">
                  <div class="elementor-element elementor-element-6a0b79f elementor-widget elementor-widget-heading" data-id="6a0b79f" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">From Our Blog</h2>		</div>
</div>
<div class="elementor-element elementor-element-4c7f4c9 elementor-widget elementor-widget-heading" data-id="4c7f4c9" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Latest Aricle</h2>		</div>
</div>
<div class="elementor-element elementor-element-e52d518 elementor-grid-2 elementor-posts--thumbnail-left elementor-grid-tablet-1 elementor-grid-mobile-1 elementor-widget elementor-widget-posts" data-id="e52d518" data-element_type="widget" data-settings="{&quot;classic_columns&quot;:&quot;2&quot;,&quot;classic_row_gap&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:20,&quot;sizes&quot;:[]},&quot;classic_row_gap_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:20,&quot;sizes&quot;:[]},&quot;classic_row_gap_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:25,&quot;sizes&quot;:[]},&quot;classic_columns_tablet&quot;:&quot;1&quot;,&quot;classic_columns_mobile&quot;:&quot;1&quot;}" data-widget_type="posts.classic">
<div class="elementor-widget-container">
<link rel="stylesheet" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor-pro/assets/css/widget-posts.min.css">		<div class="elementor-posts-container elementor-posts elementor-posts--skin-classic elementor-grid elementor-has-item-ratio">
<article class="elementor-post elementor-grid-item post-117 post type-post status-publish format-standard has-post-thumbnail hentry category-insight tag-finance tag-investment tag-trading">
<a class="elementor-post__thumbnail__link" href="https://kitnew.moxcreative.com/gettrade/2022/10/31/who-in-their-right-mind-would-even-use-facebooks-new-libra-coin/">
<div class="elementor-post__thumbnail elementor-fit-height"><img decoding="async" width="1280" height="854" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/handsome-young-businessman-holding-stack-of-cash-and-bitcoin-at-cryptocurrency-mining-farm.jpg" class="attachment-full size-full wp-image-115" alt="handsome young businessman holding stack of cash and bitcoin at cryptocurrency mining farm" loading="lazy" srcset="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/handsome-young-businessman-holding-stack-of-cash-and-bitcoin-at-cryptocurrency-mining-farm.jpg 1280w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/handsome-young-businessman-holding-stack-of-cash-and-bitcoin-at-cryptocurrency-mining-farm-300x200.jpg 300w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/handsome-young-businessman-holding-stack-of-cash-and-bitcoin-at-cryptocurrency-mining-farm-1024x684.jpg 1024w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/handsome-young-businessman-holding-stack-of-cash-and-bitcoin-at-cryptocurrency-mining-farm-768x513.jpg 768w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/handsome-young-businessman-holding-stack-of-cash-and-bitcoin-at-cryptocurrency-mining-farm-1536x1025.jpg 1536w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/handsome-young-businessman-holding-stack-of-cash-and-bitcoin-at-cryptocurrency-mining-farm-800x534.jpg 800w" sizes="(max-width: 1280px) 100vw, 1280px"></div>
</a>
<div class="elementor-post__text">
<h3 class="elementor-post__title">
<a href="https://kitnew.moxcreative.com/gettrade/2022/10/31/who-in-their-right-mind-would-even-use-facebooks-new-libra-coin/">
Who In Their Right Mind Would Even Use Facebook’s New Libra Coin?			</a>
</h3>
<div class="elementor-post__meta-data">
<span class="elementor-post-date">
October 31, 2022		</span>
<span class="elementor-post-avatar">
No Comments		</span>
</div>
<div class="elementor-post__read-more-wrapper">

<a class="elementor-post__read-more" href="https://kitnew.moxcreative.com/gettrade/2022/10/31/who-in-their-right-mind-would-even-use-facebooks-new-libra-coin/">
Read More »		</a>

</div>
</div>
</article>
<article class="elementor-post elementor-grid-item post-118 post type-post status-publish format-standard has-post-thumbnail hentry category-investment tag-finance tag-investment tag-trading">
<a class="elementor-post__thumbnail__link" href="https://kitnew.moxcreative.com/gettrade/2022/10/31/the-rise-of-wearables-this-is-why-investors-should-care/">
<div class="elementor-post__thumbnail elementor-fit-height"><img decoding="async" width="1280" height="856" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-smartwatch.jpg" class="attachment-full size-full wp-image-130" alt="Closeup of smartwatch" loading="lazy" srcset="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-smartwatch.jpg 1280w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-smartwatch-300x201.jpg 300w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-smartwatch-1024x685.jpg 1024w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-smartwatch-768x514.jpg 768w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-smartwatch-1536x1028.jpg 1536w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-smartwatch-800x535.jpg 800w" sizes="(max-width: 1280px) 100vw, 1280px"></div>
</a>
<div class="elementor-post__text">
<h3 class="elementor-post__title">
<a href="https://kitnew.moxcreative.com/gettrade/2022/10/31/the-rise-of-wearables-this-is-why-investors-should-care/">
The Rise Of Wearables: This Is Why Investors Should Care			</a>
</h3>
<div class="elementor-post__meta-data">
<span class="elementor-post-date">
October 31, 2022		</span>
<span class="elementor-post-avatar">
No Comments		</span>
</div>
<div class="elementor-post__read-more-wrapper">

<a class="elementor-post__read-more" href="https://kitnew.moxcreative.com/gettrade/2022/10/31/the-rise-of-wearables-this-is-why-investors-should-care/">
Read More »		</a>

</div>
</div>
</article>
<article class="elementor-post elementor-grid-item post-119 post type-post status-publish format-standard has-post-thumbnail hentry category-cryptocurrencies tag-finance tag-investment tag-trading">
<a class="elementor-post__thumbnail__link" href="https://kitnew.moxcreative.com/gettrade/2022/10/31/bitcoin-will-continue-its-surge-in-2021-u-s-investors-strongly-affirm-in-new-survey/">
<div class="elementor-post__thumbnail elementor-fit-height"><img decoding="async" width="1280" height="853" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-hand-holding-bitcoin-crypto-currency-coin.jpg" class="attachment-full size-full wp-image-113" alt="Closeup Of Hand Holding Bitcoin Crypto Currency Coin" loading="lazy" srcset="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-hand-holding-bitcoin-crypto-currency-coin.jpg 1280w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-hand-holding-bitcoin-crypto-currency-coin-300x200.jpg 300w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-hand-holding-bitcoin-crypto-currency-coin-1024x682.jpg 1024w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-hand-holding-bitcoin-crypto-currency-coin-768x512.jpg 768w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-hand-holding-bitcoin-crypto-currency-coin-1536x1024.jpg 1536w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/closeup-of-hand-holding-bitcoin-crypto-currency-coin-800x533.jpg 800w" sizes="(max-width: 1280px) 100vw, 1280px"></div>
</a>
<div class="elementor-post__text">
<h3 class="elementor-post__title">
<a href="https://kitnew.moxcreative.com/gettrade/2022/10/31/bitcoin-will-continue-its-surge-in-2021-u-s-investors-strongly-affirm-in-new-survey/">
Bitcoin will continue its surge in 2021, U.S. investors strongly affirm in new survey			</a>
</h3>
<div class="elementor-post__meta-data">
<span class="elementor-post-date">
October 31, 2022		</span>
<span class="elementor-post-avatar">
No Comments		</span>
</div>
<div class="elementor-post__read-more-wrapper">

<a class="elementor-post__read-more" href="https://kitnew.moxcreative.com/gettrade/2022/10/31/bitcoin-will-continue-its-surge-in-2021-u-s-investors-strongly-affirm-in-new-survey/">
Read More »		</a>

</div>
</div>
</article>
<article class="elementor-post elementor-grid-item post-120 post type-post status-publish format-standard has-post-thumbnail hentry category-finance tag-finance tag-investment tag-trading">
<a class="elementor-post__thumbnail__link" href="https://kitnew.moxcreative.com/gettrade/2022/10/31/stock-in-focus-foodies-edition-starterbucks/">
<div class="elementor-post__thumbnail elementor-fit-height"><img decoding="async" width="1280" height="853" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/coffee-bean-in-cup-with-export-text-for-import-export-trade-commerce-.jpg" class="attachment-full size-full wp-image-125" alt="Coffee bean in cup with export text for import export trade commerce." loading="lazy" srcset="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/coffee-bean-in-cup-with-export-text-for-import-export-trade-commerce-.jpg 1280w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/coffee-bean-in-cup-with-export-text-for-import-export-trade-commerce--300x200.jpg 300w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/coffee-bean-in-cup-with-export-text-for-import-export-trade-commerce--1024x682.jpg 1024w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/coffee-bean-in-cup-with-export-text-for-import-export-trade-commerce--768x512.jpg 768w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/coffee-bean-in-cup-with-export-text-for-import-export-trade-commerce--1536x1024.jpg 1536w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/coffee-bean-in-cup-with-export-text-for-import-export-trade-commerce--800x533.jpg 800w" sizes="(max-width: 1280px) 100vw, 1280px"></div>
</a>
<div class="elementor-post__text">
<h3 class="elementor-post__title">
<a href="https://kitnew.moxcreative.com/gettrade/2022/10/31/stock-in-focus-foodies-edition-starterbucks/">
Stock in Focus, Foodies Edition: Starterbucks			</a>
</h3>
<div class="elementor-post__meta-data">
<span class="elementor-post-date">
October 31, 2022		</span>
<span class="elementor-post-avatar">
No Comments		</span>
</div>
<div class="elementor-post__read-more-wrapper">

<a class="elementor-post__read-more" href="https://kitnew.moxcreative.com/gettrade/2022/10/31/stock-in-focus-foodies-edition-starterbucks/">
Read More »		</a>

</div>
</div>
</article>
</div>



</div>
</div>
</div>
</div>
            </div>
</section>