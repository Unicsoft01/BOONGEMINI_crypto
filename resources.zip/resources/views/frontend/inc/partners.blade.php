<div class="elementor-image-carousel-wrapper swiper-container" dir="ltr">

	<div class="elementor-image-carousel swiper-wrapper">

		<div class="swiper-slide"><figure class="swiper-slide-inner">
			<img decoding="async" class="swiper-slide-image" src="{{ url('/') }}/assets/partners/p1.jpg" height="50" width="192" alt="logoipsum-285" /></figure>
		</div>
		<div class="swiper-slide"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="{{ url('/') }}/assets/partners/3.png" height="50" width="192" alt="logoipsum-264" /></figure>
		</div>
		<div class="swiper-slide"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="{{ url('/') }}/assets/partners/4.png" height="50" width="192" alt="logoipsum-289" /></figure>
		</div>
		<div class="swiper-slide"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="{{ url('/') }}/assets/partners/5.png" height="50" width="192" alt="logoipsum-236 1" /></figure></div>			</div>
</div>