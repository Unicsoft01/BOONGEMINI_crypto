<section class="elementor-section elementor-top-section elementor-element elementor-element-2686e25 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2686e25" data-element_type="section">
      <div class="elementor-container elementor-column-gap-default">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7862e4e" data-id="7862e4e" data-element_type="column">
                  <div class="elementor-widget-wrap elementor-element-populated">
                        <section class="elementor-section elementor-inner-section elementor-element elementor-element-cdf16fa elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="cdf16fa" data-element_type="section">
                              <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-862ea07 elementor-invisible" data-id="862ea07" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInUp&quot;}">
                                          <div class="elementor-widget-wrap elementor-element-populated">
                                                {{-- <div class="elementor-element elementor-element-4ecacc0 ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="4ecacc0" data-element_type="widget" data-widget_type="elementskit-icon-box.default">
                                                      <div class="elementor-widget-container">
                                                            <div class="ekit-wid-con" >        <!-- link opening -->
                                                                  <!-- end link opening -->
                                                                  <div class="elementskit-infobox text-left text-left icon-top-align elementor-animation-   ">
                                                                        <div class="elementskit-box-header elementor-animation-">
                                                                              <div class="elementskit-info-box-icon  ">

                                                                                    <i aria-hidden="true" class="elementkit-infobox-icon icofont icofont-globe"></i>

                                                                              </div>

                                                                        </div>

                                                                        <div class="box-body">

                                                                              <h3 class="elementskit-info-box-title">

                                                                                    Multi Skilled</h3>

                                                                                    <p>We Buy, We sell, and Manage real Estates around the world.</p>

                                                                              </div>



                                                                        </div>

                                                                  </div>		</div>

                                                            </div>

                                                      </div>

                                                </div> --}}

                                                {{-- <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3531e7f elementor-invisible" data-id="3531e7f" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInUp&quot;,&quot;animation_delay&quot;:240}">

                                                      <div class="elementor-widget-wrap elementor-element-populated">

                                                            <div class="elementor-element elementor-element-d434635 e-transform ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="d434635" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-5,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="elementskit-icon-box.default">

                                                                  <div class="elementor-widget-container">

                                                                        <div class="ekit-wid-con" >        <!-- link opening -->

                                                                              <!-- end link opening -->


                                                                              <div class="elementskit-infobox text-left text-left icon-top-align elementor-animation-   ">

                                                                                    <div class="elementskit-box-header elementor-animation-">

                                                                                          <div class="elementskit-info-box-icon  ">

                                                                                                <i aria-hidden="true" class="elementkit-infobox-icon fas fa-search-dollar"></i>

                                                                                          </div>

                                                                                    </div>

                                                                                    <div class="box-body">

                                                                                          <h3 class="elementskit-info-box-title">

                                                                                                Transparent Pricing                </h3>

                                                                                                <p>Our Prices are Straight and Pocket friendly, no higing charges, no mago mago.</p>

                                                                                          </div>



                                                                                    </div>

                                                                              </div>		
                                                                        </div>

                                                                  </div>

                                                            </div>

                                                      </div> --}}

                                                      {{-- <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-f8f6a63 elementor-invisible" data-id="f8f6a63" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInUp&quot;,&quot;animation_delay&quot;:480}">

                                                            <div class="elementor-widget-wrap elementor-element-populated">

                                                                  <div class="elementor-element elementor-element-0c9b2c4 e-transform ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="0c9b2c4" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-5,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="elementskit-icon-box.default">
<div class="elementor-widget-container">
<div class="ekit-wid-con" >        <!-- link opening -->
<!-- end link opening -->

<div class="elementskit-infobox text-left text-left icon-top-align elementor-animation-   ">
<div class="elementskit-box-header elementor-animation-">
<div class="elementskit-info-box-icon  ">
<i aria-hidden="true" class="elementkit-infobox-icon icofont icofont-stock-mobile"></i>
</div>
</div>
<div class="box-body">
<h3 class="elementskit-info-box-title">
Innovative Tools                </h3>
<p>Magnis etiam fusce tempus condimentum montes sodales pharetra pretium.</p>
</div>


</div>
</div>		</div>
</div>
</div>
</div> --}}
{{-- <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6b88e93 elementor-invisible" data-id="6b88e93" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInUp&quot;,&quot;animation_delay&quot;:720}">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-0ba036d e-transform ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="0ba036d" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-5,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="elementskit-icon-box.default">
<div class="elementor-widget-container">
<div class="ekit-wid-con" >        <!-- link opening -->
<!-- end link opening -->

<div class="elementskit-infobox text-left text-left icon-top-align elementor-animation-   ">
<div class="elementskit-box-header elementor-animation-">
<div class="elementskit-info-box-icon  ">
<i aria-hidden="true" class="elementkit-infobox-icon icofont icofont-live-support"></i>
</div>
</div>
<div class="box-body">
<h3 class="elementskit-info-box-title">
Dedicated Support                </h3>
<p>We offer timeless support to all customers 24/7days.</p>
</div>


</div>
</div>		</div>
</div>
</div>
</div> --}}
</div>
</section>