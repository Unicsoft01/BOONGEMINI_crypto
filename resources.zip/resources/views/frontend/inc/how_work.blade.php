<section class="elementor-section elementor-top-section elementor-element elementor-element-b04ea2f elementor-reverse-tablet elementor-reverse-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b04ea2f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4c4bc8b elementor-invisible" data-id="4c4bc8b" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-482a076 elementor-widget elementor-widget-image" data-id="482a076" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img decoding="async" width="1280" height="1920" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts.jpg" class="attachment-full size-full wp-image-364" alt="Smiling businessmen drink coffee and discussing documents with graphs and charts" loading="lazy" srcset="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts.jpg 1280w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-200x300.jpg 200w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-682x1024.jpg 682w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-768x1152.jpg 768w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-1024x1536.jpg 1024w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-800x1200.jpg 800w" sizes="(max-width: 1280px) 100vw, 1280px" />															</div>
				</div>
					</div>
		</div>
<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-26e45c4 elementor-invisible" data-id="26e45c4" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInLeft&quot;}">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-c6bd603 elementor-widget elementor-widget-heading" data-id="c6bd603" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">How it works</h2>		</div>
</div>
<div class="elementor-element elementor-element-487429a elementor-widget elementor-widget-heading" data-id="487429a" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Our investment Strategies</h2>		</div>
</div>
<div class="elementor-element elementor-element-454f5b9 elementor-widget elementor-widget-text-editor" data-id="454f5b9" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<p>To start and make a successful investment you will have to follow our below steps, there are easy and simple.</p>						</div>
</div>
<div class="elementor-element elementor-element-8316e71 elementor-position-left elementor-mobile-position-left elementor-view-stacked elementor-shape-square elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="8316e71" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<link rel="stylesheet" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/css/widget-icon-box.min.css">		<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-icon">
<span class="elementor-icon elementor-animation-" >
<i aria-hidden="true" class="fa fa-sign-in"></i>				</span>
</div>
<div class="elementor-icon-box-content">
<div class="elementor-icon-box-title">
<span  >
Create an account/Login					</span>
</div>
<p class="elementor-icon-box-description">
Your account helps keep all your documents and investment details in one place					</p>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-f027646 elementor-position-left elementor-mobile-position-left elementor-view-stacked elementor-shape-square elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="f027646" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-icon">
<span class="elementor-icon elementor-animation-" >
<i aria-hidden="true" class="fa fa-money"></i>				</span>
</div>
<div class="elementor-icon-box-content">
<div class="elementor-icon-box-title">
<span  >
Make a deposit					</span>
</div>
<p class="elementor-icon-box-description">
Choose your preferred investment plan, Copy our address/account detail, make a deposit and submit an evidence of your deposit.					</p>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-f24a8b0 elementor-position-left elementor-mobile-position-left elementor-view-stacked elementor-shape-square elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="f24a8b0" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-icon">
<span class="elementor-icon elementor-animation-" >
<i aria-hidden="true" class="fa fa-refresh"></i>				</span>
</div>
<div class="elementor-icon-box-content">
<div class="elementor-icon-box-title">
<span  >
Withdraw when due					</span>
</div>
<p class="elementor-icon-box-description">
Allow your Investment process to complete, click on withdrawal to withdraw fun. Enjoy!!		</p>
</div>
</div>
</div>
</div>
</div>
</div>
							</div>
		</section>