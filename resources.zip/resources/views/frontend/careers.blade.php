<html lang="en-US"><head>
	<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<title>Careers – GetTrade</title>
<meta name="robots" content="max-image-preview:large">
<link rel="alternate" type="application/rss+xml" title="GetTrade » Feed" href="https://kitnew.moxcreative.com/gettrade/feed/">
<link rel="alternate" type="application/rss+xml" title="GetTrade » Comments Feed" href="https://kitnew.moxcreative.com/gettrade/comments/feed/">
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/kitnew.moxcreative.com\/gettrade\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.1.1"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode,e=(p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0),i.toDataURL());return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(p&&p.fillText)switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([129777,127995,8205,129778,127999],[129777,127995,8203,129778,127999])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script><script src="https://kitnew.moxcreative.com/gettrade/wp-includes/js/wp-emoji-release.min.js?ver=6.1.1" type="text/javascript" defer=""></script>
<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel="stylesheet" id="wp-block-library-css" href="https://kitnew.moxcreative.com/gettrade/wp-includes/css/dist/block-library/style.min.css?ver=6.1.1" media="all">
<link rel="stylesheet" id="classic-theme-styles-css" href="https://kitnew.moxcreative.com/gettrade/wp-includes/css/classic-themes.min.css?ver=1" media="all">
<style id="global-styles-inline-css">
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel="stylesheet" id="template-kit-export-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/template-kit-export/public/assets/css/template-kit-export-public.min.css?ver=1.0.21" media="all">
<link rel="stylesheet" id="hello-elementor-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/themes/hello-elementor/style.min.css?ver=2.6.1" media="all">
<link rel="stylesheet" id="hello-elementor-theme-style-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/themes/hello-elementor/theme.min.css?ver=2.6.1" media="all">
<link rel="stylesheet" id="elementor-frontend-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.9.0" media="all">
<link rel="stylesheet" id="elementor-post-20-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/elementor/css/post-20.css?ver=1670395129" media="all">
<link rel="stylesheet" id="elementor-icons-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.16.0" media="all">
<link rel="stylesheet" id="elementor-pro-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor-pro/assets/css/frontend-lite.min.css?ver=3.7.7" media="all">
<link rel="stylesheet" id="elementor-post-411-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/elementor/css/post-411.css?ver=1670504252" media="all">
<link rel="stylesheet" id="elementor-post-39-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/elementor/css/post-39.css?ver=1670395130" media="all">
<link rel="stylesheet" id="elementor-post-62-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/elementor/css/post-62.css?ver=1670395130" media="all">
<link rel="stylesheet" id="elementor-icons-ekiticons-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementskit-lite/modules/elementskit-icon-pack/assets/css/ekiticons.css?ver=2.8.0" media="all">
<link rel="stylesheet" id="skb-cife-brands_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/icomoon_brands.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-devicons_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/devicons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-elegant_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/elegant.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-elusive_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/elusive-icons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-icofont_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/icofont.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-icomoon_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/icomoon.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-iconic_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/iconic.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-ion_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/ionicons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-linearicons_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/linearicons.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-lineawesome_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/line-awesome.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-line_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/lineicons.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-materialdesign_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/materialdesignicons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-open_iconic-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/open-iconic.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-simpleline_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/simple-line-icons.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-themify_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/themify.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="ekit-widget-styles-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementskit-lite/widgets/init/assets/css/widget-styles.css?ver=2.8.0" media="all">
<link rel="stylesheet" id="ekit-responsive-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementskit-lite/widgets/init/assets/css/responsive.css?ver=2.8.0" media="all">
<link rel="stylesheet" id="google-fonts-1-css" href="https://fonts.googleapis.com/css?family=Oxygen%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CNoto+Sans%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CHeebo%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=auto&amp;ver=6.1.1" media="all">
<link rel="stylesheet" id="elementor-icons-skb_cife-materialdesign-icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/materialdesignicons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="elementor-icons-shared-0-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3" media="all">
<link rel="stylesheet" id="elementor-icons-fa-solid-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3" media="all">
<link rel="stylesheet" id="elementor-icons-skb_cife-open_iconic-icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/open-iconic.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="elementor-icons-skb_cife-icofont-icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/icofont.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="elementor-icons-fa-brands-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3" media="all">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin=""><script src="https://kitnew.moxcreative.com/gettrade/wp-includes/js/jquery/jquery.min.js?ver=3.6.1" id="jquery-core-js"></script>
<script src="https://kitnew.moxcreative.com/gettrade/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2" id="jquery-migrate-js"></script>
<script src="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/template-kit-export/public/assets/js/template-kit-export-public.min.js?ver=1.0.21" id="template-kit-export-js"></script>
<link rel="https://api.w.org/" href="https://kitnew.moxcreative.com/gettrade/wp-json/"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://kitnew.moxcreative.com/gettrade/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://kitnew.moxcreative.com/gettrade/wp-includes/wlwmanifest.xml">

<link rel="canonical" href="https://kitnew.moxcreative.com/gettrade/template-kit/careers/">
<link rel="shortlink" href="https://kitnew.moxcreative.com/gettrade/?p=411">
<link rel="alternate" type="application/json+oembed" href="https://kitnew.moxcreative.com/gettrade/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fkitnew.moxcreative.com%2Fgettrade%2Ftemplate-kit%2Fcareers%2F">
<link rel="alternate" type="text/xml+oembed" href="https://kitnew.moxcreative.com/gettrade/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fkitnew.moxcreative.com%2Fgettrade%2Ftemplate-kit%2Fcareers%2F&amp;format=xml">
</head>
<body class="envato_tk_templates-template envato_tk_templates-template-elementor_header_footer single single-envato_tk_templates postid-411 elementor-default elementor-template-full-width elementor-kit-20 elementor-page elementor-page-411 e--ua-blink e--ua-chrome e--ua-webkit" data-elementor-device-mode="mobile">

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-dark-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 0.49803921568627"></feFuncR><feFuncG type="table" tableValues="0 0.49803921568627"></feFuncG><feFuncB type="table" tableValues="0 0.49803921568627"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 1"></feFuncR><feFuncG type="table" tableValues="0 1"></feFuncG><feFuncB type="table" tableValues="0 1"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-purple-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.54901960784314 0.98823529411765"></feFuncR><feFuncG type="table" tableValues="0 1"></feFuncG><feFuncB type="table" tableValues="0.71764705882353 0.25490196078431"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-blue-red"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 1"></feFuncR><feFuncG type="table" tableValues="0 0.27843137254902"></feFuncG><feFuncB type="table" tableValues="0.5921568627451 0.27843137254902"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-midnight"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 0"></feFuncR><feFuncG type="table" tableValues="0 0.64705882352941"></feFuncG><feFuncB type="table" tableValues="0 1"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-magenta-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.78039215686275 1"></feFuncR><feFuncG type="table" tableValues="0 0.94901960784314"></feFuncG><feFuncB type="table" tableValues="0.35294117647059 0.47058823529412"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-purple-green"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.65098039215686 0.40392156862745"></feFuncR><feFuncG type="table" tableValues="0 1"></feFuncG><feFuncB type="table" tableValues="0.44705882352941 0.4"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-blue-orange"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.098039215686275 1"></feFuncR><feFuncG type="table" tableValues="0 0.66274509803922"></feFuncG><feFuncB type="table" tableValues="0.84705882352941 0.41960784313725"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg>
<a class="skip-link screen-reader-text" href="#content">
	Skip to content</a>

<div data-elementor-type="header" data-elementor-id="39" class="elementor elementor-39 elementor-location-header">
	@include('frontend.inc.navbar')
</div>
				<div data-elementor-type="wp-post" data-elementor-id="411" class="elementor elementor-411">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-11b4a76 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="11b4a76" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-890204b" data-id="890204b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-3eaccb4 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3eaccb4" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-b4a0a00" data-id="b4a0a00" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-fd2372e elementor-widget elementor-widget-heading animated fadeInDown" data-id="fd2372e" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInDown&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.9.0 - 06-12-2022 */
.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h2 class="elementor-heading-title elementor-size-default">Job Vacancy</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-e078755 elementor-icon-list--layout-inline elementor-align-left elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list animated fadeInRight" data-id="e078755" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css">		<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<a href="#">

											<span class="elementor-icon-list-text">Home</span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="mdi mdi-slash-forward"></i>						</span>
										<span class="elementor-icon-list-text">Careers</span>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-183b38e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="183b38e" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d5c2e51" data-id="d5c2e51" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-6ba3753 elementor-widget-divider--view-line_text elementor-widget-divider--element-align-left elementor-widget elementor-widget-divider" data-id="6ba3753" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.9.0 - 06-12-2022 */
.elementor-widget-divider{--divider-border-style:none;--divider-border-width:1px;--divider-color:#2c2c2c;--divider-icon-size:20px;--divider-element-spacing:10px;--divider-pattern-height:24px;--divider-pattern-size:20px;--divider-pattern-url:none;--divider-pattern-repeat:repeat-x}.elementor-widget-divider .elementor-divider{display:flex}.elementor-widget-divider .elementor-divider__text{font-size:15px;line-height:1;max-width:95%}.elementor-widget-divider .elementor-divider__element{margin:0 var(--divider-element-spacing);flex-shrink:0}.elementor-widget-divider .elementor-icon{font-size:var(--divider-icon-size)}.elementor-widget-divider .elementor-divider-separator{display:flex;margin:0;direction:ltr}.elementor-widget-divider--view-line_icon .elementor-divider-separator,.elementor-widget-divider--view-line_text .elementor-divider-separator{align-items:center}.elementor-widget-divider--view-line_icon .elementor-divider-separator:after,.elementor-widget-divider--view-line_icon .elementor-divider-separator:before,.elementor-widget-divider--view-line_text .elementor-divider-separator:after,.elementor-widget-divider--view-line_text .elementor-divider-separator:before{display:block;content:"";border-bottom:0;flex-grow:1;border-top:var(--divider-border-width) var(--divider-border-style) var(--divider-color)}.elementor-widget-divider--element-align-left .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-left .elementor-divider-separator:before{content:none}.elementor-widget-divider--element-align-left .elementor-divider__element{margin-left:0}.elementor-widget-divider--element-align-right .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-right .elementor-divider-separator:after{content:none}.elementor-widget-divider--element-align-right .elementor-divider__element{margin-right:0}.elementor-widget-divider:not(.elementor-widget-divider--view-line_text):not(.elementor-widget-divider--view-line_icon) .elementor-divider-separator{border-top:var(--divider-border-width) var(--divider-border-style) var(--divider-color)}.elementor-widget-divider--separator-type-pattern{--divider-border-style:none}.elementor-widget-divider--separator-type-pattern.elementor-widget-divider--view-line .elementor-divider-separator,.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:after,.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:before,.elementor-widget-divider--separator-type-pattern:not([class*=elementor-widget-divider--view]) .elementor-divider-separator{width:100%;min-height:var(--divider-pattern-height);-webkit-mask-size:var(--divider-pattern-size) 100%;mask-size:var(--divider-pattern-size) 100%;-webkit-mask-repeat:var(--divider-pattern-repeat);mask-repeat:var(--divider-pattern-repeat);background-color:var(--divider-color);-webkit-mask-image:var(--divider-pattern-url);mask-image:var(--divider-pattern-url)}.elementor-widget-divider--no-spacing{--divider-pattern-size:auto}.elementor-widget-divider--bg-round{--divider-pattern-repeat:round}.rtl .elementor-widget-divider .elementor-divider__text{direction:rtl}.e-con-inner>.elementor-widget-divider,.e-con>.elementor-widget-divider{width:var(--container-widget-width);--flex-grow:var(--container-widget-flex-grow)}</style>		<div class="elementor-divider">
			<span class="elementor-divider-separator">
							<span class="elementor-divider__text elementor-divider__element">
				Open Position				</span>
						</span>
		</div>
				</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-58677fa elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="58677fa" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-e9f904e" data-id="e9f904e" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;none&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-446e0cd elementor-widget elementor-widget-heading" data-id="446e0cd" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Staff Software Engineer</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-0a685f4 elementor-widget elementor-widget-text-editor" data-id="0a685f4" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.9.0 - 06-12-2022 */
.elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap{background-color:#818a91;color:#fff}.elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap{color:#818a91;border:3px solid;background-color:transparent}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap{margin-top:8px}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter{width:1em;height:1em}.elementor-widget-text-editor .elementor-drop-cap{float:left;text-align:center;line-height:1;font-size:50px}.elementor-widget-text-editor .elementor-drop-cap-letter{display:inline-block}</style>				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-fa73dcd elementor-widget elementor-widget-elementskit-heading" data-id="fa73dcd" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Deparment :</span></span> Engineering</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-02dca11 elementor-widget elementor-widget-elementskit-heading" data-id="02dca11" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Location :</span></span> Jakarta</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-c5d4160 elementor-widget elementor-widget-button" data-id="c5d4160" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Apply Now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-52029b7 animated fadeInLeft" data-id="52029b7" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInLeft&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d575b8b elementor-widget elementor-widget-heading" data-id="d575b8b" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Senior Mobile Engineer</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-d4c396a elementor-widget elementor-widget-text-editor" data-id="d4c396a" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-896b971 elementor-widget elementor-widget-elementskit-heading" data-id="896b971" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Deparment :</span></span> Engineering</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-191f428 elementor-widget elementor-widget-elementskit-heading" data-id="191f428" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Location :</span></span> Tangerang</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-e07888e elementor-widget elementor-widget-button" data-id="e07888e" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Apply Now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-23459a8 animated fadeInLeft" data-id="23459a8" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInLeft&quot;,&quot;animation_delay&quot;:360}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-58d3a7b elementor-widget elementor-widget-heading" data-id="58d3a7b" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Head of Information Security</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-f90ccf0 elementor-widget elementor-widget-text-editor" data-id="f90ccf0" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-1bf48f7 elementor-widget elementor-widget-elementskit-heading" data-id="1bf48f7" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Deparment :</span></span> Risk &amp; Compliance</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-996f5af elementor-widget elementor-widget-elementskit-heading" data-id="996f5af" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Location :</span></span> Jakarta</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-3236d96 elementor-widget elementor-widget-button" data-id="3236d96" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Apply Now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-41ab276 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="41ab276" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-3799eac" data-id="3799eac" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-829657e elementor-widget elementor-widget-heading" data-id="829657e" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Product Design Director</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-b0866e0 elementor-widget elementor-widget-text-editor" data-id="b0866e0" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-178f744 elementor-widget elementor-widget-elementskit-heading" data-id="178f744" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Deparment :</span></span> Design</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-aa900a1 elementor-widget elementor-widget-elementskit-heading" data-id="aa900a1" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Location :</span></span> Bandung</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-6abc4ba elementor-widget elementor-widget-button" data-id="6abc4ba" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Apply Now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-b70b88e animated fadeInLeft" data-id="b70b88e" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInLeft&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-75b9e8d elementor-widget elementor-widget-heading" data-id="75b9e8d" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Corporate Actions Specialist</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c46e580 elementor-widget elementor-widget-text-editor" data-id="c46e580" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-b024a60 elementor-widget elementor-widget-elementskit-heading" data-id="b024a60" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Deparment :</span></span> Head Office</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-485fc67 elementor-widget elementor-widget-elementskit-heading" data-id="485fc67" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Location :</span></span> Jakarta</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-075a7df elementor-widget elementor-widget-button" data-id="075a7df" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Apply Now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-d6d6b13 animated fadeInLeft" data-id="d6d6b13" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInLeft&quot;,&quot;animation_delay&quot;:360}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-53b2f10 elementor-widget elementor-widget-heading" data-id="53b2f10" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Brokerage Operations Associate</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-fd0c00f elementor-widget elementor-widget-text-editor" data-id="fd0c00f" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-d1bd14f elementor-widget elementor-widget-elementskit-heading" data-id="d1bd14f" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Deparment :</span></span> Operations</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-10c1087 elementor-widget elementor-widget-elementskit-heading" data-id="10c1087" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Location :</span></span> Surabaya</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-fd922a7 elementor-widget elementor-widget-button" data-id="fd922a7" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Apply Now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-a65cdcd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="a65cdcd" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-406d256" data-id="406d256" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-7575a32 elementor-widget elementor-widget-heading" data-id="7575a32" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Senior Financial Accountant</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-51d0c4c elementor-widget elementor-widget-text-editor" data-id="51d0c4c" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-46ca36c elementor-widget elementor-widget-elementskit-heading" data-id="46ca36c" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Deparment :</span></span> Finance</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-39c2005 elementor-widget elementor-widget-elementskit-heading" data-id="39c2005" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Location :</span></span> Semarang</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-c0adb77 elementor-widget elementor-widget-button" data-id="c0adb77" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Apply Now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2ab793a animated fadeInLeft" data-id="2ab793a" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInLeft&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e76cb21 elementor-widget elementor-widget-heading" data-id="e76cb21" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Staff Data Engineer</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-9fd170a elementor-widget elementor-widget-text-editor" data-id="9fd170a" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-eb06752 elementor-widget elementor-widget-elementskit-heading" data-id="eb06752" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Deparment :</span></span> Data</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-9ec579d elementor-widget elementor-widget-elementskit-heading" data-id="9ec579d" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Location :</span></span> Tangerang</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-ae4859b elementor-widget elementor-widget-button" data-id="ae4859b" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Apply Now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-a951593 animated fadeInLeft" data-id="a951593" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInLeft&quot;,&quot;animation_delay&quot;:360}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-1591ee2 elementor-widget elementor-widget-heading" data-id="1591ee2" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">CASS Assurance Manager</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-8d01046 elementor-widget elementor-widget-text-editor" data-id="8d01046" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-73eacdd elementor-widget elementor-widget-elementskit-heading" data-id="73eacdd" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Deparment :</span></span> Operations</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-b2d25e9 elementor-widget elementor-widget-elementskit-heading" data-id="b2d25e9" data-element_type="widget" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>Location :</span></span> Bandung</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-c17f440 elementor-widget elementor-widget-button" data-id="c17f440" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Apply Now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-34ed430 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="34ed430" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-ec3e23e" data-id="ec3e23e" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-93c0391 elementor-widget elementor-widget-heading" data-id="93c0391" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Our Value</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-28e27f5 elementor-widget elementor-widget-heading" data-id="28e27f5" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Meet the better future here</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-113daf1 elementor-widget elementor-widget-text-editor" data-id="113daf1" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Fermentum lectus senectus duis risus ipsum consequat consectetuer mauris cubilia mollis cras. Elit magnis commodo a natoque quam aptent eu lacinia semper facilisi.</p><p>Fermentum donec turpis phasellus eu dapibus condimentum hendrerit lacus ligula. Adipiscing himenaeos ornare sollicitudin dapibus si odio.</p>						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-0290477" data-id="0290477" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-1384fd9 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1384fd9" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-81d97d2" data-id="81d97d2" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-daff7e2 elementor-view-stacked e-transform elementor-vertical-align-top elementor-widget elementor-widget-icon-box animated fadeInUp" data-id="daff7e2" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-10,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/css/widget-icon-box.min.css">		<div class="elementor-icon-box-wrapper">
						<div class="elementor-icon-box-content">
				<div class="elementor-icon-box-title">
					<span>
						Candid					</span>
				</div>
									<p class="elementor-icon-box-description">
						Velit curabitur nisi consectetur at ultricies vulputate finibus ornare. Mauris scelerisque auctor mus aliquet ipsum.					</p>
							</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-8b821d2 elementor-view-stacked e-transform elementor-vertical-align-top elementor-widget elementor-widget-icon-box animated fadeInUp" data-id="8b821d2" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:360,&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-10,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">
						<div class="elementor-icon-box-content">
				<div class="elementor-icon-box-title">
					<span>
						Focused					</span>
				</div>
									<p class="elementor-icon-box-description">
						Velit curabitur nisi consectetur at ultricies vulputate finibus ornare. Mauris scelerisque auctor mus aliquet ipsum.					</p>
							</div>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-9a4164c" data-id="9a4164c" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2e7c9b8 elementor-view-stacked e-transform elementor-vertical-align-top elementor-widget elementor-widget-icon-box animated fadeInDown" data-id="2e7c9b8" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInDown&quot;,&quot;_animation_delay&quot;:360,&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-10,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">
						<div class="elementor-icon-box-content">
				<div class="elementor-icon-box-title">
					<span>
						Curious					</span>
				</div>
									<p class="elementor-icon-box-description">
						Velit curabitur nisi consectetur at ultricies vulputate finibus ornare. Mauris scelerisque auctor mus aliquet ipsum.					</p>
							</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-f86db28 elementor-view-stacked e-transform elementor-vertical-align-top elementor-widget elementor-widget-icon-box animated fadeInDown" data-id="f86db28" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInDown&quot;,&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-10,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">
						<div class="elementor-icon-box-content">
				<div class="elementor-icon-box-title">
					<span>
						Humble					</span>
				</div>
									<p class="elementor-icon-box-description">
						Velit curabitur nisi consectetur at ultricies vulputate finibus ornare. Mauris scelerisque auctor mus aliquet ipsum.					</p>
							</div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-2c98680 elementor-reverse-tablet elementor-reverse-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2c98680" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-d0a844e animated fadeInUp" data-id="d0a844e" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-b77b5bb elementor-widget elementor-widget-image" data-id="b77b5bb" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img decoding="async" width="1280" height="852" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/smart-stock-trading-investor-analyze-the-financial-market-of-cryptocurrencies-invests-in-e.jpg" class="attachment-full size-full wp-image-114" alt="Smart stock trading investor, analyze the financial market of cryptocurrencies, invests in e" loading="lazy" srcset="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/smart-stock-trading-investor-analyze-the-financial-market-of-cryptocurrencies-invests-in-e.jpg 1280w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/smart-stock-trading-investor-analyze-the-financial-market-of-cryptocurrencies-invests-in-e-300x200.jpg 300w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/smart-stock-trading-investor-analyze-the-financial-market-of-cryptocurrencies-invests-in-e-1024x681.jpg 1024w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/smart-stock-trading-investor-analyze-the-financial-market-of-cryptocurrencies-invests-in-e-768x511.jpg 768w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/smart-stock-trading-investor-analyze-the-financial-market-of-cryptocurrencies-invests-in-e-1536x1022.jpg 1536w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/10/smart-stock-trading-investor-analyze-the-financial-market-of-cryptocurrencies-invests-in-e-800x532.jpg 800w" sizes="(max-width: 1280px) 100vw, 1280px">															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-9dc0886" data-id="9dc0886" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-9209955 elementor-widget elementor-widget-heading" data-id="9209955" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Why Join Us</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-263448d elementor-widget elementor-widget-heading" data-id="263448d" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">We're a team of mission-driven experts &amp; learners</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-a36d6de elementor-widget elementor-widget-text-editor" data-id="a36d6de" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Finibus vehicula felis per est taciti sollicitudin nostra tempor integer aenean class. Iaculis nostra commodo cubilia luctus tristique per tempus ligula libero.</p>						</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-a040dd5 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="a040dd5" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-51d7874 elementor-invisible" data-id="51d7874" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInRight&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-cf3ba78 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="cf3ba78" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-chevron-circle-right"></i>						</span>
										<span class="elementor-icon-list-text">Culture and Events</span>
									</li>
						</ul>
				</div>
				</div>
				<div class="elementor-element elementor-element-8fcefba elementor-widget elementor-widget-text-editor" data-id="8fcefba" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Venenatis maecenas litora lacinia tellus lobortis torquent porta ornare. Ut ante penatibus ultrices neque eget.</p>						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-0615706 elementor-invisible" data-id="0615706" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInRight&quot;,&quot;animation_delay&quot;:360}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-f75718c elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="f75718c" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-chevron-circle-right"></i>						</span>
										<span class="elementor-icon-list-text">Employee Benefits</span>
									</li>
						</ul>
				</div>
				</div>
				<div class="elementor-element elementor-element-333f7d8 elementor-widget elementor-widget-text-editor" data-id="333f7d8" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Venenatis maecenas litora lacinia tellus lobortis torquent porta ornare. Ut ante penatibus ultrices neque eget.</p>						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-87fab19 elementor-invisible" data-id="87fab19" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInRight&quot;,&quot;animation_delay&quot;:720}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-64724a5 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="64724a5" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-chevron-circle-right"></i>						</span>
										<span class="elementor-icon-list-text">Work Hard, Play Harder</span>
									</li>
						</ul>
				</div>
				</div>
				<div class="elementor-element elementor-element-61ac27c elementor-widget elementor-widget-text-editor" data-id="61ac27c" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Venenatis maecenas litora lacinia tellus lobortis torquent porta ornare. Ut ante penatibus ultrices neque eget.</p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-2a53a91 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2a53a91" data-element_type="section">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-dbcff6f" data-id="dbcff6f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated e-swiper-container">
								<div class="elementor-element elementor-element-0743efb elementor-invisible elementor-widget elementor-widget-elementskit-heading" data-id="0743efb" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInDown&quot;}" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper text_center   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title "><span><span>GetTrade</span></span> is trusted by 6+ million users in 175+ countries</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-bcedd31 elementor-widget elementor-widget-text-editor" data-id="bcedd31" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-b528130 elementor-widget elementor-widget-image-carousel e-widget-swiper" data-id="b528130" data-element_type="widget" data-settings="{&quot;slides_to_show&quot;:&quot;4&quot;,&quot;slides_to_show_tablet&quot;:&quot;4&quot;,&quot;slides_to_show_mobile&quot;:&quot;3&quot;,&quot;slides_to_scroll&quot;:&quot;1&quot;,&quot;navigation&quot;:&quot;none&quot;,&quot;image_spacing_custom&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:40,&quot;sizes&quot;:[]},&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;yes&quot;,&quot;speed&quot;:500}" data-widget_type="image-carousel.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.9.0 - 06-12-2022 */
.elementor-widget-image-carousel .swiper-container{position:static}.elementor-widget-image-carousel .swiper-container .swiper-slide figure{line-height:inherit}.elementor-widget-image-carousel .swiper-slide{text-align:center}.elementor-image-carousel-wrapper:not(.swiper-container-initialized) .swiper-slide{max-width:calc(100% / var(--e-image-carousel-slides-to-show, 3))}</style>		<div class="elementor-image-carousel-wrapper swiper-container swiper-container-initialized swiper-container-horizontal" dir="ltr">
			<div class="elementor-image-carousel swiper-wrapper" style="transform: translate3d(-940.333px, 0px, 0px); transition-duration: 0ms;"><div class="swiper-slide swiper-slide-duplicate" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="1"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-264.png" alt="logoipsum-264"></figure></div><div class="swiper-slide swiper-slide-duplicate" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="2"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-289.png" alt="logoipsum-289"></figure></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="3"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-236-1.png" alt="logoipsum-236 1"></figure></div>
								<div class="swiper-slide swiper-slide-duplicate-active" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="0"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-285.png" alt="logoipsum-285"></figure></div><div class="swiper-slide swiper-slide-duplicate-next" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="1"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-264.png" alt="logoipsum-264"></figure></div><div class="swiper-slide" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="2"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-289.png" alt="logoipsum-289"></figure></div><div class="swiper-slide swiper-slide-prev" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="3"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-236-1.png" alt="logoipsum-236 1"></figure></div>			<div class="swiper-slide swiper-slide-duplicate swiper-slide-active" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="0"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-285.png" alt="logoipsum-285"></figure></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-next" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="1"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-264.png" alt="logoipsum-264"></figure></div><div class="swiper-slide swiper-slide-duplicate" style="width: 94.3333px; margin-right: 40px;" data-swiper-slide-index="2"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/logoipsum-289.png" alt="logoipsum-289"></figure></div></div>
																<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
							</div>
@include('frontend.inc.footer')
