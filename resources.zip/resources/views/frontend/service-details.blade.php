<html lang="en-US"><head>
	<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<title>Service Detail – GetTrade</title>
<meta name="robots" content="max-image-preview:large">
<link rel="alternate" type="application/rss+xml" title="GetTrade » Feed" href="https://kitnew.moxcreative.com/gettrade/feed/">
<link rel="alternate" type="application/rss+xml" title="GetTrade » Comments Feed" href="https://kitnew.moxcreative.com/gettrade/comments/feed/">
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/kitnew.moxcreative.com\/gettrade\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.1.1"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode,e=(p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0),i.toDataURL());return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(p&&p.fillText)switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([129777,127995,8205,129778,127999],[129777,127995,8203,129778,127999])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script><script src="https://kitnew.moxcreative.com/gettrade/wp-includes/js/wp-emoji-release.min.js?ver=6.1.1" type="text/javascript" defer=""></script>
<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel="stylesheet" id="wp-block-library-css" href="https://kitnew.moxcreative.com/gettrade/wp-includes/css/dist/block-library/style.min.css?ver=6.1.1" media="all">
<link rel="stylesheet" id="classic-theme-styles-css" href="https://kitnew.moxcreative.com/gettrade/wp-includes/css/classic-themes.min.css?ver=1" media="all">
<style id="global-styles-inline-css">
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel="stylesheet" id="template-kit-export-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/template-kit-export/public/assets/css/template-kit-export-public.min.css?ver=1.0.21" media="all">
<link rel="stylesheet" id="hello-elementor-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/themes/hello-elementor/style.min.css?ver=2.6.1" media="all">
<link rel="stylesheet" id="hello-elementor-theme-style-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/themes/hello-elementor/theme.min.css?ver=2.6.1" media="all">
<link rel="stylesheet" id="elementor-frontend-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.9.0" media="all">
<link rel="stylesheet" id="elementor-post-20-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/elementor/css/post-20.css?ver=1670395129" media="all">
<link rel="stylesheet" id="elementor-icons-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.16.0" media="all">
<link rel="stylesheet" id="elementor-pro-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor-pro/assets/css/frontend-lite.min.css?ver=3.7.7" media="all">
<link rel="stylesheet" id="elementor-post-685-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/elementor/css/post-685.css?ver=1670395129" media="all">
<link rel="stylesheet" id="elementor-post-39-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/elementor/css/post-39.css?ver=1670395130" media="all">
<link rel="stylesheet" id="elementor-post-62-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/elementor/css/post-62.css?ver=1670395130" media="all">
<link rel="stylesheet" id="elementor-icons-ekiticons-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementskit-lite/modules/elementskit-icon-pack/assets/css/ekiticons.css?ver=2.8.0" media="all">
<link rel="stylesheet" id="skb-cife-brands_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/icomoon_brands.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-devicons_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/devicons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-elegant_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/elegant.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-elusive_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/elusive-icons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-icofont_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/icofont.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-icomoon_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/icomoon.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-iconic_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/iconic.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-ion_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/ionicons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-linearicons_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/linearicons.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-lineawesome_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/line-awesome.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-line_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/lineicons.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-materialdesign_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/materialdesignicons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-open_iconic-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/open-iconic.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-simpleline_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/simple-line-icons.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="skb-cife-themify_icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/themify.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="ekit-widget-styles-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementskit-lite/widgets/init/assets/css/widget-styles.css?ver=2.8.0" media="all">
<link rel="stylesheet" id="ekit-responsive-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementskit-lite/widgets/init/assets/css/responsive.css?ver=2.8.0" media="all">
<link rel="stylesheet" id="google-fonts-1-css" href="https://fonts.googleapis.com/css?family=Oxygen%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CNoto+Sans%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CHeebo%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=auto&amp;ver=6.1.1" media="all">
<link rel="stylesheet" id="elementor-icons-skb_cife-materialdesign-icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/materialdesignicons.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="elementor-icons-skb_cife-icofont-icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/icofont.min.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="elementor-icons-shared-0-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3" media="all">
<link rel="stylesheet" id="elementor-icons-fa-solid-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3" media="all">
<link rel="stylesheet" id="elementor-icons-skb_cife-iconic-icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/iconic.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="elementor-icons-skb_cife-open_iconic-icon-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/skyboot-custom-icons-for-elementor/assets/css/open-iconic.css?ver=1.0.5" media="all">
<link rel="stylesheet" id="elementor-icons-fa-brands-css" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3" media="all">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin=""><script src="https://kitnew.moxcreative.com/gettrade/wp-includes/js/jquery/jquery.min.js?ver=3.6.1" id="jquery-core-js"></script>
<script src="https://kitnew.moxcreative.com/gettrade/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2" id="jquery-migrate-js"></script>
<script src="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/template-kit-export/public/assets/js/template-kit-export-public.min.js?ver=1.0.21" id="template-kit-export-js"></script>
<link rel="https://api.w.org/" href="https://kitnew.moxcreative.com/gettrade/wp-json/"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://kitnew.moxcreative.com/gettrade/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://kitnew.moxcreative.com/gettrade/wp-includes/wlwmanifest.xml">

<link rel="canonical" href="https://kitnew.moxcreative.com/gettrade/template-kit/service-detail/">
<link rel="shortlink" href="https://kitnew.moxcreative.com/gettrade/?p=685">
<link rel="alternate" type="application/json+oembed" href="https://kitnew.moxcreative.com/gettrade/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fkitnew.moxcreative.com%2Fgettrade%2Ftemplate-kit%2Fservice-detail%2F">
<link rel="alternate" type="text/xml+oembed" href="https://kitnew.moxcreative.com/gettrade/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fkitnew.moxcreative.com%2Fgettrade%2Ftemplate-kit%2Fservice-detail%2F&amp;format=xml">
</head>
<body class="envato_tk_templates-template envato_tk_templates-template-elementor_header_footer single single-envato_tk_templates postid-685 elementor-default elementor-template-full-width elementor-kit-20 elementor-page elementor-page-685 e--ua-blink e--ua-chrome e--ua-webkit" data-elementor-device-mode="mobile">

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-dark-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 0.49803921568627"></feFuncR><feFuncG type="table" tableValues="0 0.49803921568627"></feFuncG><feFuncB type="table" tableValues="0 0.49803921568627"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 1"></feFuncR><feFuncG type="table" tableValues="0 1"></feFuncG><feFuncB type="table" tableValues="0 1"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-purple-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.54901960784314 0.98823529411765"></feFuncR><feFuncG type="table" tableValues="0 1"></feFuncG><feFuncB type="table" tableValues="0.71764705882353 0.25490196078431"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-blue-red"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 1"></feFuncR><feFuncG type="table" tableValues="0 0.27843137254902"></feFuncG><feFuncB type="table" tableValues="0.5921568627451 0.27843137254902"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-midnight"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 0"></feFuncR><feFuncG type="table" tableValues="0 0.64705882352941"></feFuncG><feFuncB type="table" tableValues="0 1"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-magenta-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.78039215686275 1"></feFuncR><feFuncG type="table" tableValues="0 0.94901960784314"></feFuncG><feFuncB type="table" tableValues="0.35294117647059 0.47058823529412"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-purple-green"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.65098039215686 0.40392156862745"></feFuncR><feFuncG type="table" tableValues="0 1"></feFuncG><feFuncB type="table" tableValues="0.44705882352941 0.4"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-blue-orange"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.098039215686275 1"></feFuncR><feFuncG type="table" tableValues="0 0.66274509803922"></feFuncG><feFuncB type="table" tableValues="0.84705882352941 0.41960784313725"></feFuncB><feFuncA type="table" tableValues="1 1"></feFuncA></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"></feComposite></filter></defs></svg>
<a class="skip-link screen-reader-text" href="#content">
	Skip to content</a>

<div data-elementor-type="header" data-elementor-id="39" class="elementor elementor-39 elementor-location-header">
	@include('frontend.inc.navbar')
</div>
				<div data-elementor-type="wp-post" data-elementor-id="685" class="elementor elementor-685">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-c7cebce elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c7cebce" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8403517" data-id="8403517" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-a6c859c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="a6c859c" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-0af9cc5" data-id="0af9cc5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ab26f22 elementor-icon-list--layout-inline elementor-align-left elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list animated fadeInRight" data-id="ab26f22" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css">		<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<a href="#">

											<span class="elementor-icon-list-text">Home</span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="mdi mdi-slash-forward"></i>						</span>
										<span class="elementor-icon-list-text">Services</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="mdi mdi-slash-forward"></i>						</span>
										<span class="elementor-icon-list-text">Trading</span>
									</li>
						</ul>
				</div>
				</div>
				<div class="elementor-element elementor-element-b4419a3 elementor-widget elementor-widget-heading animated fadeInDown" data-id="b4419a3" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInDown&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.9.0 - 06-12-2022 */
.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h2 class="elementor-heading-title elementor-size-default">Make Trading Yours</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-b757a3a elementor-widget elementor-widget-text-editor animated fadeIn" data-id="b757a3a" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:720}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.9.0 - 06-12-2022 */
.elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap{background-color:#818a91;color:#fff}.elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap{color:#818a91;border:3px solid;background-color:transparent}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap{margin-top:8px}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter{width:1em;height:1em}.elementor-widget-text-editor .elementor-drop-cap{float:left;text-align:center;line-height:1;font-size:50px}.elementor-widget-text-editor .elementor-drop-cap-letter{display:inline-block}</style>				<p>Curae habitant venenatis tempus himenaeos inceptos scelerisque mauris ante maximus. Congue porttitor magna litora tristique molestie tempus mauris per eros himenaeos. Pharetra consectetur conubia ut himenaeos.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-3dc3311 elementor-widget elementor-widget-button animated fadeInUp" data-id="3dc3311" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:1080}" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Read More</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-3aab64e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3aab64e" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-fe02407 animated bounceInUp" data-id="fe02407" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInUp&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-26663bc ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="26663bc" data-element_type="widget" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con">        <!-- link opening -->
                <!-- end link opening -->

        <div class="elementskit-infobox text-left text-left icon-top-align elementor-animation-   ">
                    <div class="elementskit-box-header elementor-animation-">
                <div class="elementskit-info-box-icon  ">
                    <i aria-hidden="true" class="elementkit-infobox-icon icofont icofont-globe"></i>
                </div>
          </div>
                        <div class="box-body">
                            <h3 class="elementskit-info-box-title">
                    Wide Product Range                </h3>
                        		  <p>Magnis etiam fusce tempus condimentum montes sodales pharetra pretium.</p>
                                </div>
        
        
                </div>
        </div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-eb4c7e6 animated bounceInUp" data-id="eb4c7e6" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInUp&quot;,&quot;animation_delay&quot;:240}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-45c83b1 e-transform ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="45c83b1" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-5,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con">        <!-- link opening -->
                <!-- end link opening -->

        <div class="elementskit-infobox text-left text-left icon-top-align elementor-animation-   ">
                    <div class="elementskit-box-header elementor-animation-">
                <div class="elementskit-info-box-icon  ">
                    <i aria-hidden="true" class="elementkit-infobox-icon fas fa-search-dollar"></i>
                </div>
          </div>
                        <div class="box-body">
                            <h3 class="elementskit-info-box-title">
                    Transparent Pricing                </h3>
                        		  <p>Magnis etiam fusce tempus condimentum montes sodales pharetra pretium.</p>
                                </div>
        
        
                </div>
        </div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6ddd6d8 animated bounceInUp" data-id="6ddd6d8" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInUp&quot;,&quot;animation_delay&quot;:480}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-b8fe292 e-transform ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="b8fe292" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-5,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con">        <!-- link opening -->
                <!-- end link opening -->

        <div class="elementskit-infobox text-left text-left icon-top-align elementor-animation-   ">
                    <div class="elementskit-box-header elementor-animation-">
                <div class="elementskit-info-box-icon  ">
                    <i aria-hidden="true" class="elementkit-infobox-icon icofont icofont-stock-mobile"></i>
                </div>
          </div>
                        <div class="box-body">
                            <h3 class="elementskit-info-box-title">
                    Innovative Tools                </h3>
                        		  <p>Magnis etiam fusce tempus condimentum montes sodales pharetra pretium.</p>
                                </div>
        
        
                </div>
        </div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-5058790 animated bounceInUp" data-id="5058790" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInUp&quot;,&quot;animation_delay&quot;:720}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-90374cf e-transform ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="90374cf" data-element_type="widget" data-settings="{&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-5,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con">        <!-- link opening -->
                <!-- end link opening -->

        <div class="elementskit-infobox text-left text-left icon-top-align elementor-animation-   ">
                    <div class="elementskit-box-header elementor-animation-">
                <div class="elementskit-info-box-icon  ">
                    <i aria-hidden="true" class="elementkit-infobox-icon icofont icofont-live-support"></i>
                </div>
          </div>
                        <div class="box-body">
                            <h3 class="elementskit-info-box-title">
                    Dedicated Support                </h3>
                        		  <p>Magnis etiam fusce tempus condimentum montes sodales pharetra pretium.</p>
                                </div>
        
        
                </div>
        </div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-431b0fd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="431b0fd" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-28be8f9" data-id="28be8f9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4aab460 elementor-widget elementor-widget-heading animated fadeInDown" data-id="4aab460" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInDown&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">All-in-one trading account</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-d110fd3 elementor-widget elementor-widget-text-editor" data-id="d110fd3" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Dapibus velit scelerisque phasellus fermentum id habitasse. Inceptos pharetra aptent fames velit amet finibus elit montes blandit suspendisse. Fames quisque nascetur lorem dictum natoque egestas potenti dapibus neque posuere nisi.</p>						</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-b6a2455 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b6a2455" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-9e43fd7" data-id="9e43fd7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-480c1a0 elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="480c1a0" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="iconic iconic-check-alt"></i>						</span>
										<span class="elementor-icon-list-text">Stocks &amp; EFTs</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="iconic iconic-check-alt"></i>						</span>
										<span class="elementor-icon-list-text">Metals</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="iconic iconic-check-alt"></i>						</span>
										<span class="elementor-icon-list-text">Options</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="iconic iconic-check-alt"></i>						</span>
										<span class="elementor-icon-list-text">Bonds</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-62ccafe" data-id="62ccafe" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4499499 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="4499499" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="iconic iconic-check-alt"></i>						</span>
										<span class="elementor-icon-list-text">Currencies</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="iconic iconic-check-alt"></i>						</span>
										<span class="elementor-icon-list-text">Futures</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="iconic iconic-check-alt"></i>						</span>
										<span class="elementor-icon-list-text">Funds</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<div class="elementor-element elementor-element-d6e9bb3 elementor-widget elementor-widget-button" data-id="d6e9bb3" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
							<span class="elementor-button-icon elementor-align-icon-right">
				<i aria-hidden="true" class="fas fa-chevron-circle-right"></i>			</span>
						<span class="elementor-button-text">Get Started</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-26eeb07" data-id="26eeb07" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-dbf47db elementor-widget elementor-widget-image animated fadeInRight" data-id="dbf47db" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img decoding="async" width="1280" height="854" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/business-man-trader-investor-analyst-checking-trading-data-.jpg" class="attachment-full size-full wp-image-549" alt="Business man trader investor analyst checking trading data." loading="lazy" srcset="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/business-man-trader-investor-analyst-checking-trading-data-.jpg 1280w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/business-man-trader-investor-analyst-checking-trading-data--300x200.jpg 300w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/business-man-trader-investor-analyst-checking-trading-data--1024x683.jpg 1024w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/business-man-trader-investor-analyst-checking-trading-data--768x512.jpg 768w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/business-man-trader-investor-analyst-checking-trading-data--1536x1025.jpg 1536w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/business-man-trader-investor-analyst-checking-trading-data--800x534.jpg 800w" sizes="(max-width: 1280px) 100vw, 1280px">															</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-4623bb8 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4623bb8" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-2128ad2 elementor-invisible" data-id="2128ad2" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInLeft&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-c9fad08 elementor-widget__width-initial elementor-widget elementor-widget-counter" data-id="c9fad08" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.9.0 - 06-12-2022 */
.elementor-counter .elementor-counter-number-wrapper{display:flex;font-size:69px;font-weight:600;line-height:1}.elementor-counter .elementor-counter-number-prefix,.elementor-counter .elementor-counter-number-suffix{flex-grow:1;white-space:pre-wrap}.elementor-counter .elementor-counter-number-prefix{text-align:right}.elementor-counter .elementor-counter-number-suffix{text-align:left}.elementor-counter .elementor-counter-title{text-align:center;font-size:19px;font-weight:400;line-height:2.5}</style>		<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="600000" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix">+</span>
			</div>
							<div class="elementor-counter-title">Instruments</div>
					</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-d18d59d elementor-widget__width-initial elementor-widget elementor-widget-counter" data-id="d18d59d" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="50" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix">+</span>
			</div>
							<div class="elementor-counter-title">Markets</div>
					</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-03c645e elementor-widget__width-initial elementor-widget elementor-widget-counter" data-id="03c645e" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix">$</span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="50" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix">M</span>
			</div>
							<div class="elementor-counter-title">Charter Capital</div>
					</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-86f22f4 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="86f22f4" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a4592ce" data-id="a4592ce" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-7841c4b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="7841c4b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-c3f8983 elementor-invisible" data-id="c3f8983" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInRight&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4ec583e elementor-widget elementor-widget-heading" data-id="4ec583e" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Get up to $600 plus 60 days of commission-free stocks &amp; forex trades</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-615e27d elementor-widget elementor-widget-text-editor" data-id="615e27d" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-51c776f elementor-widget elementor-widget-button" data-id="51c776f" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
							<span class="elementor-button-icon elementor-align-icon-right">
				<i aria-hidden="true" class="fas fa-chevron-circle-right"></i>			</span>
						<span class="elementor-button-text">Open  Account </span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-4d30b89 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4d30b89" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-453fe96" data-id="453fe96" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-9391873 elementor-widget elementor-widget-heading" data-id="9391873" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Pricing Package</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-2a12bdf elementor-widget elementor-widget-heading" data-id="2a12bdf" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Choose the best plan that fit for you</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-cae85ae elementor-widget__width-initial elementor-widget elementor-widget-text-editor" data-id="cae85ae" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>						</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-f0f54c2 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="f0f54c2" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-45fab8f elementor-invisible" data-id="45fab8f" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:360}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-0c9b037 elementor-widget elementor-widget-price-table" data-id="0c9b037" data-element_type="widget" data-widget_type="price-table.default">
				<div class="elementor-widget-container">
			<style>/*! elementor-pro - v3.7.7 - 20-09-2022 */
.elementor-widget-price-list .elementor-price-list{list-style:none;padding:0;margin:0}.elementor-widget-price-list .elementor-price-list li{margin:0}.elementor-price-list li:not(:last-child){margin-bottom:20px}.elementor-price-list .elementor-price-list-image{max-width:50%;-ms-flex-negative:0;flex-shrink:0;padding-right:25px}.elementor-price-list .elementor-price-list-image img{width:100%}.elementor-price-list .elementor-price-list-header,.elementor-price-list .elementor-price-list-item,.elementor-price-list .elementor-price-list-text{display:-webkit-box;display:-ms-flexbox;display:flex}.elementor-price-list .elementor-price-list-item{-webkit-box-align:start;-ms-flex-align:start;align-items:flex-start}.elementor-price-list .elementor-price-list-item .elementor-price-list-text{-webkit-box-align:start;-ms-flex-align:start;align-items:flex-start;-ms-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1}.elementor-price-list .elementor-price-list-item .elementor-price-list-header{-webkit-box-align:center;-ms-flex-align:center;align-items:center;-ms-flex-preferred-size:100%;flex-basis:100%;font-size:19px;font-weight:600;margin-bottom:10px;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}.elementor-price-list .elementor-price-list-item .elementor-price-list-title{max-width:80%}.elementor-price-list .elementor-price-list-item .elementor-price-list-price{font-weight:600}.elementor-price-list .elementor-price-list-item p.elementor-price-list-description{-ms-flex-preferred-size:100%;flex-basis:100%;font-size:14px;margin:0}.elementor-price-list .elementor-price-list-item .elementor-price-list-separator{-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:10px;margin-right:10px;border-bottom-style:dotted;border-bottom-width:2px;height:0}.elementor-price-table{text-align:center}.elementor-price-table .elementor-price-table__header{background:var(--e-price-table-header-background-color,#555);padding:20px 0}.elementor-price-table .elementor-price-table__heading{margin:0;padding:0;line-height:1.2;font-size:24px;font-weight:600;color:#fff}.elementor-price-table .elementor-price-table__subheading{font-size:13px;font-weight:400;color:#fff}.elementor-price-table .elementor-price-table__original-price{margin-right:15px;text-decoration:line-through;font-size:.5em;line-height:1;font-weight:400;-ms-flex-item-align:center;align-self:center}.elementor-price-table .elementor-price-table__original-price .elementor-price-table__currency{font-size:1em;margin:0}.elementor-price-table .elementor-price-table__price{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-ms-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-direction:row;flex-direction:row;color:#555;font-weight:800;font-size:65px;padding:40px 0}.elementor-price-table .elementor-price-table__price .elementor-typo-excluded{line-height:normal;letter-spacing:normal;text-transform:none;font-weight:400;font-size:medium;font-style:normal}.elementor-price-table .elementor-price-table__after-price{display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;text-align:left;-ms-flex-item-align:stretch;align-self:stretch;-webkit-box-align:start;-ms-flex-align:start;align-items:flex-start;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}.elementor-price-table .elementor-price-table__integer-part{line-height:.8}.elementor-price-table .elementor-price-table__currency,.elementor-price-table .elementor-price-table__fractional-part{line-height:1;font-size:.3em}.elementor-price-table .elementor-price-table__currency{margin-right:3px}.elementor-price-table .elementor-price-table__period{width:100%;font-size:13px;font-weight:400}.elementor-price-table .elementor-price-table__features-list{list-style-type:none;margin:0;padding:0;line-height:1;color:var(--e-price-table-features-list-color)}.elementor-price-table .elementor-price-table__features-list li{font-size:14px;line-height:1;margin:0;padding:0}.elementor-price-table .elementor-price-table__features-list li .elementor-price-table__feature-inner{margin-left:15px;margin-right:15px}.elementor-price-table .elementor-price-table__features-list li:not(:first-child):before{content:"";display:block;border:0 solid hsla(0,0%,47.8%,.3);margin:10px 12.5%}.elementor-price-table .elementor-price-table__features-list i{margin-right:10px;font-size:1.3em}.elementor-price-table .elementor-price-table__features-list svg{margin-right:10px;fill:var(--e-price-table-features-list-color);height:1.3em;width:1.3em}.elementor-price-table .elementor-price-table__features-list svg~*{vertical-align:text-top}.elementor-price-table .elementor-price-table__footer{padding:30px 0}.elementor-price-table .elementor-price-table__additional_info{margin:0;font-size:13px;line-height:1.4}.elementor-price-table__ribbon{position:absolute;top:0;left:auto;right:0;-webkit-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg);width:150px;overflow:hidden;height:150px}.elementor-price-table__ribbon-inner{text-align:center;left:0;width:200%;-webkit-transform:translateY(-50%) translateX(-50%) translateX(35px) rotate(-45deg);-ms-transform:translateY(-50%) translateX(-50%) translateX(35px) rotate(-45deg);transform:translateY(-50%) translateX(-50%) translateX(35px) rotate(-45deg);margin-top:35px;font-size:13px;line-height:2;font-weight:800;text-transform:uppercase;background:#000}.elementor-price-table__ribbon.elementor-ribbon-left{-webkit-transform:rotate(0);-ms-transform:rotate(0);transform:rotate(0);left:0;right:auto}.elementor-price-table__ribbon.elementor-ribbon-right{-webkit-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg);left:auto;right:0}.elementor-widget-price-table .elementor-widget-container{overflow:hidden;background-color:#f7f7f7}.e-container>.elementor-widget-price-list,.e-container__inner>.elementor-widget-price-list{width:var(--container-widget-width,100%)}</style>
		<div class="elementor-price-table">
							<div class="elementor-price-table__header">
											<h3 class="elementor-price-table__heading">
						Basic						</h3>
					
											<span class="elementor-price-table__subheading">
							Accounts						</span>
									</div>
			
			<div class="elementor-price-table__price">
								<span class="elementor-price-table__currency">$</span>									<span class="elementor-price-table__integer-part">
						0					</span>
				
									<div class="elementor-price-table__after-price">
						<span class="elementor-price-table__fractional-part">
							00						</span>

											</div>
				
				
									<span class="elementor-price-table__period elementor-typo-excluded">/ Monthly</span>							</div>

							<ul class="elementor-price-table__features-list">
											<li class="elementor-repeater-item-d29a67d">
							<div class="elementor-price-table__feature-inner">
								<i aria-hidden="true" class="iconic iconic-check-alt"></i>																	<span>
										General investment account									</span>
																</div>
						</li>
											<li class="elementor-repeater-item-f472b82">
							<div class="elementor-price-table__feature-inner">
								<i aria-hidden="true" class="iconic iconic-x-altx-alt"></i>																	<span>
										Stocks and shares ISA									</span>
																</div>
						</li>
											<li class="elementor-repeater-item-6a918c9">
							<div class="elementor-price-table__feature-inner">
								<i aria-hidden="true" class="iconic iconic-x-altx-alt"></i>																	<span>
										Self-invested personal pension									</span>
																</div>
						</li>
									</ul>
			
							<div class="elementor-price-table__footer">
											<a class="elementor-price-table__button elementor-button elementor-size-md" href="#">
							Choose Plan						</a>
					
									</div>
					</div>

				</div>
				</div>
				<div class="elementor-element elementor-element-18cfeea elementor-widget elementor-widget-heading" data-id="18cfeea" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Benefit :</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-d5cdb98 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="d5cdb98" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Automated order types</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Advanced stock fundamentals</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Fractional US Shares</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Priority customer service</span>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-ee26cc4 elementor-invisible" data-id="ee26cc4" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-445710f elementor-widget elementor-widget-price-table" data-id="445710f" data-element_type="widget" data-widget_type="price-table.default">
				<div class="elementor-widget-container">
			
		<div class="elementor-price-table">
							<div class="elementor-price-table__header">
											<h3 class="elementor-price-table__heading">
						Standart						</h3>
					
											<span class="elementor-price-table__subheading">
							Accounts						</span>
									</div>
			
			<div class="elementor-price-table__price">
								<span class="elementor-price-table__currency">$</span>									<span class="elementor-price-table__integer-part">
						19					</span>
				
									<div class="elementor-price-table__after-price">
						<span class="elementor-price-table__fractional-part">
							00						</span>

											</div>
				
				
									<span class="elementor-price-table__period elementor-typo-excluded">/ Monthly</span>							</div>

							<ul class="elementor-price-table__features-list">
											<li class="elementor-repeater-item-d29a67d">
							<div class="elementor-price-table__feature-inner">
								<i aria-hidden="true" class="iconic iconic-check-alt"></i>																	<span>
										General investment account									</span>
																</div>
						</li>
											<li class="elementor-repeater-item-f472b82">
							<div class="elementor-price-table__feature-inner">
								<i aria-hidden="true" class="iconic iconic-check-alt"></i>																	<span>
										Stocks and shares ISA									</span>
																</div>
						</li>
											<li class="elementor-repeater-item-6a918c9">
							<div class="elementor-price-table__feature-inner">
								<i aria-hidden="true" class="iconic iconic-x-altx-alt"></i>																	<span>
										Self-invested personal pension									</span>
																</div>
						</li>
									</ul>
			
							<div class="elementor-price-table__footer">
											<a class="elementor-price-table__button elementor-button elementor-size-md" href="#">
							Choose Plan						</a>
					
									</div>
					</div>

					<div class="elementor-price-table__ribbon">
				<div class="elementor-price-table__ribbon-inner">
					Best Choice				</div>
			</div>
					</div>
				</div>
				<div class="elementor-element elementor-element-e2cfca9 elementor-widget elementor-widget-heading" data-id="e2cfca9" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Benefit :</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-26468d0 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="26468d0" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Automated order types</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Advanced stock fundamentals</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Fractional US Shares</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Priority customer service</span>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-cf62841 elementor-invisible" data-id="cf62841" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:720}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-6a94650 elementor-widget elementor-widget-price-table" data-id="6a94650" data-element_type="widget" data-widget_type="price-table.default">
				<div class="elementor-widget-container">
			
		<div class="elementor-price-table">
							<div class="elementor-price-table__header">
											<h3 class="elementor-price-table__heading">
						Plus						</h3>
					
											<span class="elementor-price-table__subheading">
							Accounts						</span>
									</div>
			
			<div class="elementor-price-table__price">
								<span class="elementor-price-table__currency">$</span>									<span class="elementor-price-table__integer-part">
						49					</span>
				
									<div class="elementor-price-table__after-price">
						<span class="elementor-price-table__fractional-part">
							00						</span>

											</div>
				
				
									<span class="elementor-price-table__period elementor-typo-excluded">/ Monthly</span>							</div>

							<ul class="elementor-price-table__features-list">
											<li class="elementor-repeater-item-d29a67d">
							<div class="elementor-price-table__feature-inner">
								<i aria-hidden="true" class="iconic iconic-check-alt"></i>																	<span>
										General investment account									</span>
																</div>
						</li>
											<li class="elementor-repeater-item-f472b82">
							<div class="elementor-price-table__feature-inner">
								<i aria-hidden="true" class="iconic iconic-check-alt"></i>																	<span>
										Stocks and shares ISA									</span>
																</div>
						</li>
											<li class="elementor-repeater-item-6a918c9">
							<div class="elementor-price-table__feature-inner">
								<i aria-hidden="true" class="iconic iconic-check-alt"></i>																	<span>
										Self-invested personal pension									</span>
																</div>
						</li>
									</ul>
			
							<div class="elementor-price-table__footer">
											<a class="elementor-price-table__button elementor-button elementor-size-md" href="#">
							Choose Plan						</a>
					
									</div>
					</div>

				</div>
				</div>
				<div class="elementor-element elementor-element-992bfa7 elementor-widget elementor-widget-heading" data-id="992bfa7" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Benefit :</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-67f8292 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="67f8292" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Automated order types</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Advanced stock fundamentals</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Fractional US Shares</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="oi oi-check"></i>						</span>
										<span class="elementor-icon-list-text">Priority customer service</span>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-2ccfc62 elementor-reverse-tablet elementor-reverse-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2ccfc62" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-dddd080 elementor-invisible" data-id="dddd080" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-dd467c5 elementor-widget elementor-widget-image" data-id="dd467c5" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img decoding="async" width="1280" height="1920" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts.jpg" class="attachment-full size-full wp-image-364" alt="Smiling businessmen drink coffee and discussing documents with graphs and charts" loading="lazy" srcset="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts.jpg 1280w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-200x300.jpg 200w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-682x1024.jpg 682w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-768x1152.jpg 768w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-1024x1536.jpg 1024w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/smiling-businessmen-drink-coffee-and-discussing-documents-with-graphs-and-charts-800x1200.jpg 800w" sizes="(max-width: 1280px) 100vw, 1280px">															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-7765cce elementor-invisible" data-id="7765cce" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInLeft&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d23dc0f elementor-widget elementor-widget-heading" data-id="d23dc0f" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Why Choose Us</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c48c5ac elementor-widget elementor-widget-heading" data-id="c48c5ac" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">An investment that takes you to great heights</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-df8eed9 elementor-widget elementor-widget-text-editor" data-id="df8eed9" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-1af2660 elementor-position-left elementor-mobile-position-left elementor-view-stacked elementor-shape-square elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="1af2660" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="https://kitnew.moxcreative.com/gettrade/wp-content/plugins/elementor/assets/css/widget-icon-box.min.css">		<div class="elementor-icon-box-wrapper">
						<div class="elementor-icon-box-icon">
				<span class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class="oi oi-check"></i>				</span>
			</div>
						<div class="elementor-icon-box-content">
				<div class="elementor-icon-box-title">
					<span>
						Trusted by Investor					</span>
				</div>
									<p class="elementor-icon-box-description">
						Suscipit class etiam letius efficitur a hac accumsan si. Lacinia arcu dictumst a penatibus non fermentum donec sociosqu sed vulputate ante.					</p>
							</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-0d448f9 elementor-position-left elementor-mobile-position-left elementor-view-stacked elementor-shape-square elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="0d448f9" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">
						<div class="elementor-icon-box-icon">
				<span class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class="oi oi-check"></i>				</span>
			</div>
						<div class="elementor-icon-box-content">
				<div class="elementor-icon-box-title">
					<span>
						Invest With Confidence					</span>
				</div>
									<p class="elementor-icon-box-description">
						Suscipit class etiam letius efficitur a hac accumsan si. Lacinia arcu dictumst a penatibus non fermentum donec sociosqu sed vulputate ante.					</p>
							</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-93901b0 elementor-position-left elementor-mobile-position-left elementor-view-stacked elementor-shape-square elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="93901b0" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">
						<div class="elementor-icon-box-icon">
				<span class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class="oi oi-check"></i>				</span>
			</div>
						<div class="elementor-icon-box-content">
				<div class="elementor-icon-box-title">
					<span>
						Secure Platform					</span>
				</div>
									<p class="elementor-icon-box-description">
						Suscipit class etiam letius efficitur a hac accumsan si. Lacinia arcu dictumst a penatibus non fermentum donec sociosqu sed vulputate ante.					</p>
							</div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-10c3944 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="10c3944" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-7eeb5ed elementor-invisible" data-id="7eeb5ed" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInLeft&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-786ae02 elementor-widget elementor-widget-elementskit-heading" data-id="786ae02" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con"><div class="ekit-heading elementskit-section-title-wraper    ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title ">Download <span><span>GetTrade</span></span> Apps</h2></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-f6cc13e elementor-widget elementor-widget-text-editor" data-id="f6cc13e" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Ridiculus fusce maecenas ut blandit tempus. Lorem semper penatibus venenatis convallis efficitur. Placerat laoreet pellentesque aliquet habitant eleifend quis ridiculus dictumst habitasse.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-4306ed9 elementor-widget__width-initial elementor-widget elementor-widget-image" data-id="4306ed9" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
																<a href="#">
							<img decoding="async" width="216" height="64" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/App-Store_button.png" class="attachment-full size-full wp-image-637" alt="" loading="lazy">								</a>
															</div>
				</div>
				<div class="elementor-element elementor-element-5f1b2dd elementor-widget__width-initial elementor-widget elementor-widget-image" data-id="5f1b2dd" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
																<a href="#">
							<img decoding="async" width="216" height="64" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/Google-Play_button.png" class="attachment-full size-full wp-image-638" alt="" loading="lazy">								</a>
															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-23c02e7 elementor-invisible" data-id="23c02e7" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInRight&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2b9522a elementor-absolute e-transform elementor-widget elementor-widget-image" data-id="2b9522a" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_transform_rotateZ_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:6,&quot;sizes&quot;:[]},&quot;_animation&quot;:&quot;none&quot;,&quot;_transform_rotateZ_effect_tablet&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_rotateZ_effect_mobile&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img decoding="async" width="600" height="617" src="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/Apps-Trading-Mockup-2-1.png" class="attachment-full size-full wp-image-640" alt="" loading="lazy" srcset="https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/Apps-Trading-Mockup-2-1.png 600w, https://kitnew.moxcreative.com/gettrade/wp-content/uploads/sites/8/2022/11/Apps-Trading-Mockup-2-1-292x300.png 292w" sizes="(max-width: 600px) 100vw, 600px">															</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-01d50f7 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="01d50f7" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-58078ec" data-id="58078ec" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-6ced3e6 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6ced3e6" data-element_type="section" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-3447ae0" data-id="3447ae0" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-c5dbdb9 elementor-widget elementor-widget-heading" data-id="c5dbdb9" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">FAQ</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-38c352c elementor-invisible elementor-widget elementor-widget-heading" data-id="38c352c" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">What can we help?</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c508999 elementor-widget elementor-widget-text-editor" data-id="c508999" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-bb9eca8 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="bb9eca8" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-ad8937a elementor-invisible" data-id="ad8937a" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-37da1e6 elementor-widget elementor-widget-elementskit-accordion" data-id="37da1e6" data-element_type="widget" data-widget_type="elementskit-accordion.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con">
        <div class="elementskit-accordion accoedion-primary" id="accordion-639a4cd30fa2b">

            
                <div class="elementskit-card active">
                    <div class="elementskit-card-header" id="primaryHeading-0-37da1e6">
                        <a href="#collapse-6f49139639a4cd30fa2b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-6f49139639a4cd30fa2b" aria-expanded="true" aria-controls="Collapse-6f49139639a4cd30fa2b">
                            
                            <span class="ekit-accordion-title">What are dividends? Do they get reinvested?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-6f49139639a4cd30fa2b" class=" show collapse" aria-labelledby="primaryHeading-0-37da1e6" data-parent="#accordion-639a4cd30fa2b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                
                <div class="elementskit-card ">
                    <div class="elementskit-card-header" id="primaryHeading-1-37da1e6">
                        <a href="#collapse-042b378639a4cd30fa2b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-042b378639a4cd30fa2b" aria-expanded="false" aria-controls="Collapse-042b378639a4cd30fa2b">
                            
                            <span class="ekit-accordion-title">What factors go into my Retirement goal?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-042b378639a4cd30fa2b" class=" collapse" aria-labelledby="primaryHeading-1-37da1e6" data-parent="#accordion-639a4cd30fa2b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                
                <div class="elementskit-card ">
                    <div class="elementskit-card-header" id="primaryHeading-2-37da1e6">
                        <a href="#collapse-fcc8da4639a4cd30fa2b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-fcc8da4639a4cd30fa2b" aria-expanded="false" aria-controls="Collapse-fcc8da4639a4cd30fa2b">
                            
                            <span class="ekit-accordion-title">Why is my deposit still pending?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-fcc8da4639a4cd30fa2b" class=" collapse" aria-labelledby="primaryHeading-2-37da1e6" data-parent="#accordion-639a4cd30fa2b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                
                <div class="elementskit-card ">
                    <div class="elementskit-card-header" id="primaryHeading-3-37da1e6">
                        <a href="#collapse-247bb1b639a4cd30fa2b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-247bb1b639a4cd30fa2b" aria-expanded="false" aria-controls="Collapse-247bb1b639a4cd30fa2b">
                            
                            <span class="ekit-accordion-title">Why does my investing account say “funding in progress”?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-247bb1b639a4cd30fa2b" class=" collapse" aria-labelledby="primaryHeading-3-37da1e6" data-parent="#accordion-639a4cd30fa2b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                
                <div class="elementskit-card ">
                    <div class="elementskit-card-header" id="primaryHeading-4-37da1e6">
                        <a href="#collapse-43386d3639a4cd30fa2b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-43386d3639a4cd30fa2b" aria-expanded="false" aria-controls="Collapse-43386d3639a4cd30fa2b">
                            
                            <span class="ekit-accordion-title">How can I reactivate my membership?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-43386d3639a4cd30fa2b" class=" collapse" aria-labelledby="primaryHeading-4-37da1e6" data-parent="#accordion-639a4cd30fa2b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                        </div>
    </div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-851c3cf elementor-invisible" data-id="851c3cf" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:360}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-0d041f7 elementor-widget elementor-widget-elementskit-accordion" data-id="0d041f7" data-element_type="widget" data-widget_type="elementskit-accordion.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con">
        <div class="elementskit-accordion accoedion-primary" id="accordion-639a4cd311b7b">

            
                <div class="elementskit-card active">
                    <div class="elementskit-card-header" id="primaryHeading-0-0d041f7">
                        <a href="#collapse-042b378639a4cd311b7b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-042b378639a4cd311b7b" aria-expanded="true" aria-controls="Collapse-042b378639a4cd311b7b">
                            
                            <span class="ekit-accordion-title">What factors go into my Retirement goal?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-042b378639a4cd311b7b" class=" show collapse" aria-labelledby="primaryHeading-0-0d041f7" data-parent="#accordion-639a4cd311b7b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                
                <div class="elementskit-card ">
                    <div class="elementskit-card-header" id="primaryHeading-1-0d041f7">
                        <a href="#collapse-6f49139639a4cd311b7b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-6f49139639a4cd311b7b" aria-expanded="false" aria-controls="Collapse-6f49139639a4cd311b7b">
                            
                            <span class="ekit-accordion-title">What are dividends? Do they get reinvested?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-6f49139639a4cd311b7b" class=" collapse" aria-labelledby="primaryHeading-1-0d041f7" data-parent="#accordion-639a4cd311b7b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                
                <div class="elementskit-card ">
                    <div class="elementskit-card-header" id="primaryHeading-2-0d041f7">
                        <a href="#collapse-43386d3639a4cd311b7b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-43386d3639a4cd311b7b" aria-expanded="false" aria-controls="Collapse-43386d3639a4cd311b7b">
                            
                            <span class="ekit-accordion-title">How can I reactivate my membership?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-43386d3639a4cd311b7b" class=" collapse" aria-labelledby="primaryHeading-2-0d041f7" data-parent="#accordion-639a4cd311b7b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                
                <div class="elementskit-card ">
                    <div class="elementskit-card-header" id="primaryHeading-3-0d041f7">
                        <a href="#collapse-247bb1b639a4cd311b7b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-247bb1b639a4cd311b7b" aria-expanded="false" aria-controls="Collapse-247bb1b639a4cd311b7b">
                            
                            <span class="ekit-accordion-title">Why does my investing account say “funding in progress”?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-247bb1b639a4cd311b7b" class=" collapse" aria-labelledby="primaryHeading-3-0d041f7" data-parent="#accordion-639a4cd311b7b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                
                <div class="elementskit-card ">
                    <div class="elementskit-card-header" id="primaryHeading-4-0d041f7">
                        <a href="#collapse-fcc8da4639a4cd311b7b" class="ekit-accordion--toggler elementskit-btn-link collapsed" data-ekit-toggle="collapse" data-target="#Collapse-fcc8da4639a4cd311b7b" aria-expanded="false" aria-controls="Collapse-fcc8da4639a4cd311b7b">
                            
                            <span class="ekit-accordion-title">Why is my deposit still pending?</span>

                            
                                <div class="ekit_accordion_icon_group">
                                    <div class="ekit_accordion_normal_icon">
                                        <!-- Normal Icon -->
                                        <i aria-hidden="true" class="icon-open icon-right fas fa-chevron-circle-right"></i>                                    </div>

                                    <div class="ekit_accordion_active_icon">
                                        <!-- Active Icon -->
                                        <i aria-hidden="true" class="icon-closed icon-right fas fa-chevron-circle-down"></i>                                    </div>

                                </div>

                            
                                                    </a>
                    </div>

                    <div id="Collapse-fcc8da4639a4cd311b7b" class=" collapse" aria-labelledby="primaryHeading-4-0d041f7" data-parent="#accordion-639a4cd311b7b">

                        <div class="elementskit-card-body ekit-accordion--content">
                            <p>Velit sociosqu purus enim pharetra sed sem at iaculis. Felis ridiculus adipiscing dignissim eros pellentesque mus vitae litora. Felis nullam tortor phasellus viverra ut arcu. Euismod magnis ante convallis vulputate odio augue sit pretium dapibus.</p>                        </div>

                    </div>

                </div><!-- .elementskit-card END -->

                        </div>
    </div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
							</div>
							@include('frontend.inc.footer')
