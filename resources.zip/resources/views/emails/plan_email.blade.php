<!DOCTYPE html>
<html>
<head>
    <title>{{ $subject }}</title>
</head>
<body>
    <h4 style="text-align: center"><center>{{ $subject }}</center></h4>
    <p>{{ $body }}</p>
    <h3>order summary is giving below</h3>
    <p>Transaction ID: {{ $transaction_id }}</p>
    <p>Plan: {{ $plan }}</p>
    <p>Amount: {{ $Amount }}</p>
    <p>Thank you</p>
  <hr>
    <p>Boongemini - Powered by Unicsoft Tech.</p>
     
</body>
</html>