<!DOCTYPE html>
<html>
<head>
    <title>{{ $subject }}</title>
</head>
<body>
    <h4 style="text-align: center"><center>{{ $subject }}</center></h4>
    <p>{{ $body }}</p>
    <p>Thank you</p>
  <hr>
    <p>Boongemini - Powered by Unicsoft Tech.</p>
     
</body>
</html>